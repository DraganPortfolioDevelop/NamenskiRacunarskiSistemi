import matplotlib.pyplot as plt
import requests
import re
from bs4 import BeautifulSoup
import subprocess

# Lista modula neophodnih za pokretanje ove aplikacije
# Neophodno je instalirati 'pipreqs'
subprocess.run(['pipreqs', '--force'])

# preuzimanje podataka sa sajta halo oglasi
url = 'https://www.halooglasi.com/nekretnine/prodaja-stanova/arandjelovac'
stranica = requests.get(url)
soup = BeautifulSoup(stranica.content, 'html.parser')
podatak = soup.find_all('div', class_='product-item')

# kreiranje prazne liste za pomenute podatke 
cena = [] # lista cena 
kvadratura = [] # lista kvadratura 

 # petlja prolazi kroz veb stranicu i uzima trazene podatke
for stavka in podatak: 

    # uzima trazenu cenu i dodaje je u listu 
    cena_stavka = stavka.find('div', class_='central-feature').text
    # nadjenu cenu dodaje u listu 'cena'
    cena.append(cena_stavka)

    # uzima trazenu kvadraturu i dodaje je u listu  
    kvadratura_stavka = stavka.find('div', class_='value-wrapper').text
    # pravi novu listu kako bi ostranili nepotrebne podatke
    novi_stavka_kvadratude = []
    # prolazi kroz sve karaktere i skida poslednji 10, so odgovara reci 'Kvadratura'
    for i in range(len(kvadratura_stavka)-10):
        # dodaje novo kreirane podatke u listu
        novi_stavka_kvadratude.append(kvadratura_stavka[i])
    # pridruzuje karaktere za svaku cenu
    kvadratura_stavka = ''.join(str(x) for x in novi_stavka_kvadratude)
    
    # formatirane cene dodaje u listu 'kvadratura'  
    kvadratura.append(kvadratura_stavka)

# kreira 2D plot za Cenu i Kvadraturu
plt.scatter(cena, kvadratura, color='red')  

# postavlja opis za x i y osu  
plt.xlabel('Cena')  
plt.ylabel('Kvadratura')  

# postavlja naslov za 2D plot  
plt.title('Odnos Cena i Kvadrature stanova u Arandjelovcu - 2D Plot')  

# prikazuje 2D plot u zasebnom prozoru  
plt.show()