
import os
import subprocess
from PIL import Image

# Lista modula neophodnih za pokretanje ove aplikacije
# Neophodno je instalirati 'pipreqs'
subprocess.run(['pipreqs', '--force'])

# funkcija obrade vodenim zigom
def vodeni_zig_obrada():

    # Putanja foldera u kome se nalaze slike
    folder_slike = 'slike/'

    # Putanja slike vodenog ziga 
    vodeni_zig_putanja = 'vodeni_zig.png' 

    # Petlja prolazi kroz sve fajlove u folderu slike 
    for fajl in os.listdir(folder_slike):

        # Poveravaju se ekstenzije u folderu. Nama trebaju samo slike.  
        if fajl.endswith(".jpg") or fajl.endswith(".png"):

            # Otvara sliku u folderu 
            slika = Image.open(f'{folder_slike}{fajl}')

            # Otvara fajl sa vodenim zigom 
            vodeni_zig = Image.open(vodeni_zig_putanja)

            # kalkulise velicinu fajla 
            pozicija = ((slika.width - vodeni_zig.width) // 2, (slika.height - vodeni_zig.height) // 2)

            # dodaje vodeni zig na sliku
            slika.paste(vodeni_zig, pozicija)

            # cuva novu sliku na zadatoj putanji 
            slika.save(f'slike/vodeni_zig/vz_{fajl}')

# funkcija obrade slike iz kolora u crno belu varijantu
def crno_bela_obrada():

    # Putanja foldera u kome se nalaze slike
    folder_slike = 'slike/'

    # Petlja prolazi kroz sve fajlove u folderu slike 
    for fajl in os.listdir(folder_slike):
 
        # Poveravaju se ekstenzije u folderu. Nama trebaju samo slike.  
        if fajl.endswith(".jpg") or fajl.endswith(".png"):

            # Otvara sliku u folderu
            slika = Image.open(f'{folder_slike}{fajl}')

            # Crno bela obrada slike
            crno_bela_slika = slika.convert('L')

            # Sacuvati izmenu
            crno_bela_slika.save(f'slike/crno_bela/cb_{fajl}')  

# program se okrece u petlji do prekida programa unosenjem nule 
while True:

    print('\n\t\tOBRADA SLIKE\n',
          '[1] Vodeni zig\n',
          '[2] Crno-Bela slika\n',
          '[0] Izlaz iz programa\n')

    unos = input('Unesite broj ispred zeljene obrade [Broj]:' )

    if unos == '1':
        # Provera da li folder 'vodeni_zig' postoji
        if not os.path.exists('slike/vodeni_zig/'):
            # Ukoliko ne postoji kreirati folder 'vodeni_zig'
            os.mkdir('slike/vodeni_zig/')
        vodeni_zig_obrada()

    elif unos == '2':
        # Provera da li folder 'crno_bela' postoji
        if not os.path.exists('slike/crno_bela/'):
            # Ukoliko ne postoji kreirati folder 'crno_bela'
            os.mkdir('slike/crno_bela/')
        crno_bela_obrada()

    elif unos == '0':
        print('Izasli ste iz programa!!!')
        break
        

